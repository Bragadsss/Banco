const usuarios = {
    "David": "senha",
    "Artur": "senha",
    "Richard": "senha"
};
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); 
    
    const nome = document.getElementById("nome").value;
    const senha = document.getElementById("senha").value;

    if (nome in usuarios && usuarios[nome] === senha) {
        document.getElementById("resultado").textContent = "Acesso permitido";
        
    } else {
        document.getElementById("resultado").textContent = "Acesso negado";
        
    }
});
